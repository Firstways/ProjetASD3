

public class Dual {
    public Quadtree quad;
    public String region;

    public Dual (Quadtree quad, String r){
        region = r;
        this.quad = quad;
    }
}
